# student_profile_management_system

# to install requirements

pip install -r requirements.txt

# import database

students.sql
